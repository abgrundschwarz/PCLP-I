#include <iostream>
using namespace std;

int main()
{
    #credeti ma ca stiu cum se face exercitiul cu ajutorul if, dar e prea plictisitor (am facut cu if exercitiul acest langa tabla)
    int a,b,m;
    cin >> a >> b;
    m=max(a,b);
    cout << m;
    return 0;
}
