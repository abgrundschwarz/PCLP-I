#include <iostream>

using namespace std;

int main()
{
    int num;
    cin >> num;
    if (num%2==1){cout<<"impar";}
    else{cout<<"par";}
    return 0;
}
