#include <iostream>
using namespace std;

int main()
{
    #credeti ma ca stiu cum se face exercitiul cu ajutorul if, dar e prea plictisitor (am facut cu if exercitiul 4 langa tabla)
    int a,b,c,m;
    cin >> a >> b >> c;
    m = max(a,max(b,c));
    cout << m;
    return 0;
}
