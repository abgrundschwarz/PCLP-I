#include <iostream>
using namespace std;

int main()
{
    int a,b;
    cin >> a >> b;
    if (a>=10)
        {
        cout <<2*a-2*b<<endl;
        }
    else if (a<=-3)
        {
        cout <<"5"<<endl;
        }
    else
        {
        cout <<a*b<<endl;
        }

    return 0;
}
