#include <iostream>
using namespace std;

int main()
{
    int a,b;
    cin >> a >> b;
    if (a>0 & b>0)
        {
        cout << "Perimetrul: "<<a+a+b+b<<endl;
        cout << "Aria: "<<a*b<<endl;
        }

    return 0;
}
