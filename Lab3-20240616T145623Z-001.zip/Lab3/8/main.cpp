#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float a,b,c,p;
    cin >> a >> b >> c;
    p = (a+b+c)/2;
    if (a+b>c & b+c>a & a+c>b)
        {
        cout << "Perimetrul: "<<a+b+c<<endl;
        cout << "Aria: "<<sqrt(p*(p-a)*(p-b)*(p-c))<<endl;
        }
    else
        {
        cout << "Error"<<endl;
        }
    return 0;
}
