#include <iostream>

using namespace std;

int main()
{
    float a,b,x;
    cout<<"a*x+b=0"<<endl;
    cout<<"Introduceti a,b"<<endl;
    cin >> a >> b;
    if (a!=0)
    {
        cout<<(-b)/a<<endl;
    }
    else {cout<<"Error"<<endl;}
    return 0;
}
