#include <iostream>

using namespace std;

int main()
{
    int nota;
    cin >> nota;
    if (nota>=5){cout<<"Promovat!";}
    else {cout<<":(";}
    return 0;
}
